﻿Partial Class UserAccountDataSet
    Partial Public Class tbl_FoodDataTable
    End Class
End Class
